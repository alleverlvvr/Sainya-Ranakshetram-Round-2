#include <iostream>
using namespace std;
int main(void)
{
  int arr[10];
  int arr_num;
  long long int ex = 9999999999; // out of range of int used for buffer overflow attack
  int num,i;

   cout << "Enter the count of numbers? ";
   cin >> num;
   num = ex;  // using this method as it is harder to detect stack smashing in this manner

  for (i = 0; i < num; i++)
  {
    cout << "Enter a number to be stored: ";
    cin >> arr_num;
    arr[i]= arr_num;
  }
  return 0;
}
