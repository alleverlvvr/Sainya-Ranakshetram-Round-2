#include<stdio.h>

int main()
{
        FILE *fp;
        fp = fopen("abc.txt", "r");
        if (fp == NULL) {
            printf("File Not Found!\n");
            exit(1);
            }
        fseek(fp, 0L, SEEK_END);
        long int res = ftell(fp);
        fclose(fp);
        FILE *fptr;
        fptr = fopen("abc.txt","w");
        if(fptr == NULL) {
            printf("Error!");
            exit(1);
        }
        for (long int i = 0; i < res; i++) {
            fprintf(fptr,"X");
        }
        fclose(fptr);
        printf("Data overwritten successfully thus lost permanently\n");
    if (remove("abc.txt") == 0) {
        printf("Deleted successfully");
        exit(0);
    }
    else
        printf("Unable to delete the file");
    return 0;
}
